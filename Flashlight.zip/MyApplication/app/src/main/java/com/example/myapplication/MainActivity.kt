package com.example.myapplication

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random


class MainActivity : AppCompatActivity() {
    private lateinit var b1 : Button
    private lateinit var b2 : Button
    private lateinit var b3 : Button
    private lateinit var b4 : Button
    private lateinit var b5 : Button
    private lateinit var b6 : Button
    private lateinit var b7 : Button
    private lateinit var b8 : Button
    private lateinit var layout: LinearLayout
    private lateinit var toggleButton: ImageButton
    private var arr: Array<String> = arrayOf("#FFFFFF","#800080","#00FF00","#FF9900","#800000","#FFFF00","#FF33CC","#00FFFF")
    @SuppressLint("MissingInflatedId")
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
            b1 = findViewById(R.id.button)
            b2 = findViewById(R.id.button2)
            b3 = findViewById(R.id.button3)
            b4 = findViewById(R.id.button4)
            b5 = findViewById(R.id.button5)
            b6 = findViewById(R.id.button6)
            b7 = findViewById(R.id.button7)
            b8 = findViewById(R.id.button8)
            layout = findViewById(R.id.layout)
            toggleButton = findViewById(R.id.toggleButton);

        toggleButton.setOnClickListener{
            var c =  Random.nextInt(0, 7) + 1
            layout.setBackgroundColor(Color.parseColor(arr.get(c)))

        }

        b1.setOnClickListener{
                layout.setBackgroundColor(Color.WHITE)
                }

            b2.setOnClickListener{
                layout.setBackgroundColor(Color.GREEN)
                }
            b3.setOnClickListener {
                layout.setBackgroundColor(Color.CYAN)
                }
            b4.setOnClickListener{
                layout.setBackgroundColor(Color.YELLOW)
                }
            b5.setOnClickListener{
                layout.setBackgroundColor(Color.rgb(128,0,128))
                }
            b6.setOnClickListener{
                layout.setBackgroundColor(Color.rgb(255, 51, 204))
                }
            b7.setOnClickListener{
                layout.setBackgroundColor(Color.rgb(255, 153, 0))
                }
            b8.setOnClickListener{
                layout.setBackgroundColor(Color.rgb(128, 0, 0))
                }
        }

   
}

